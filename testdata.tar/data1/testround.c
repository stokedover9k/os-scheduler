#include <stdio.h>

main()
{
    float a,b;
    a = 1.0/3.0;
    b = 2.0/3.0;
    printf("%.2f %.2f\n",  a, b);
    printf("%.3f %.3f\n",  a, b);

}

